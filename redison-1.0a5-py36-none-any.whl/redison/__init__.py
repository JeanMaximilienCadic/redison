from .redis_object import RedisObject
__version__="1.0a5"